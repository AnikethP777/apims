const express = require('express');
const app = express();

const port = process.env.PORT || 4000;

app.get("/",(req,res)=>{
    res.send(`This is the consul instances page\nrunning on the port ${port}`);
});

app.listen(port,()=>{
    console.log(`Server is running on port ${port}`);
});
